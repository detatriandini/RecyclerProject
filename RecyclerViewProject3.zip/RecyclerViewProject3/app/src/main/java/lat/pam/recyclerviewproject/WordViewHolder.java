package lat.pam.recyclerviewproject;

public interface WordViewHolder {
}
